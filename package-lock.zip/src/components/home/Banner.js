import React from 'react';
import { Carousel } from 'antd-mobile';


class App extends React.Component {
  constructor (props) {
    super (props);
    this.state = {
      data: [1, 2]
    }
  }
  componentDidMount() {
    fetch ('/x/web-show/res/loc?jsonp=jsonp&pf=7&id=1695')
    .then(res => res.json())
    .then(data => {
      console.log(data)
    })

    fetch ('http://www.daxunxun.com/banner')
    .then(res => res.json())
    .then(data => {
      this.setState({ data })
    })
    // // simulate img loading
    // setTimeout(() => {
    //   this.setState({
    //     data: ['AiyWuByWklrrUDlFignR', 'TekJlZRVCjLFexlOCuWn', 'IJOtIlfsYdTyaDTRVrLI'],
    //   });
    // }, 100);
  }
  render() {
    return (
        <Carousel
          autoplay
          infinite
        >
          {this.state.data.map((val, index) => (
            // <a
            //   key={val}
            //   href="http://www.alipay.com"
            //   style={{ display: 'inline-block', width: '100%', height: this.state.imgHeight }}
            // >
              <img
                key = {index}
                src={`http://www.daxunxun.com${val}`}
                alt=""
                // style={{ width: '100%', verticalAlign: 'top' }}
                onLoad={() => {
                  // fire window resize event to change height
                  window.dispatchEvent(new Event('resize'));
                }}
              />
            // </a>
          ))}
        </Carousel>
    );
  }
}

export default App;