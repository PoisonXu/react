import React from 'react';

class Com extends React.Component {
  render () {
    return (
      <main>
        <header className = "header">
          这是cart头部
        </header>
        <div className = "content">
          这是文档区
        </div>
      </main>
    )
  }
}

export default Com;