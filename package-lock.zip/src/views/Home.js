import React from 'react';
import HomeContent from '@/components/home/HomeContent'

class Com extends React.Component {
  constructor (props) {
    super(props);
    this.state = {
      contentList: []
    }
  }

  componentDidMount () {
    fetch ('http://www.daxunxun.com/douban')
    .then(res => res.json())
    .then(data => {
      this.setState({
        contentList: data
      })
    })
  }

  render () {
    return (
      <main>
        <header className = "header">
          这是home头部
        </header>
        <HomeContent contentList = { this.state.contentList }/>
      </main>
    )
  }
}

export default Com;